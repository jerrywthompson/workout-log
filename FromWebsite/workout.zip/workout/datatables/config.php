<?php


define (DB_USER, "jerrwler");
define (DB_PASSWORD, "5EkUJ565s7D8y");
define (DB_DATABASE, "jerrwler_workout");
define (DB_HOST, "localhost");

$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);


?>