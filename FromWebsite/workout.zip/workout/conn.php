<?php
 
//MySQLi Procedural
$conn = mysqli_connect("localhost","jerrwler","5EkUJ565s7D8y","jerrwler_workout");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
 
?>