$(function() {
  $('#datetimepicker1').datetimepicker({
    language: 'pt-BR'
  });
});